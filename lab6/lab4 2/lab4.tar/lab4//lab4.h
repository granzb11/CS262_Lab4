#ifndef LAB4_H
#define LAB4_H
#define RNG_SEED 3074
#define ARRAYLEN 200
#define LOOPS 100

void InitializeArray(int *numArray, const int length);
void randperm(int *a, const int n);


#endif

